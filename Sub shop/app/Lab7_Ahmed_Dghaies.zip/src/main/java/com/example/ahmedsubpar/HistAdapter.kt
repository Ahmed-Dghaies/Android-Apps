package com.example.ahmedsubpar

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.*
import kotlin.collections.ArrayList

class HistAdapter() : RecyclerView.Adapter<HistAdapter.ViewHolder>() {

    private var orderHistoryList: List<OrderHistory>? = null

    //this method is returning the view for each item in the list
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.list_layout, parent, false)
        return ViewHolder(v)
    }

    //this method is binding the data on the list
    override fun onBindViewHolder(holder: HistAdapter.ViewHolder, position: Int) {
        val order_date = holder.itemView.findViewById<TextView>(R.id.order_date)
        val order_description = holder.itemView.findViewById<TextView>(R.id.order_description_item)

        if (orderHistoryList != null) {
            val hist = orderHistoryList?.get(position)?: OrderHistory(null, "", Date())
            order_date.text = hist.orderDate.toString()
            order_description.text = hist.orderDescription
        } else {
            order_date.text = ""
            order_description.text = ""
        }
    }


    //this method is giving the size of the list
    override fun getItemCount(): Int {
        return this.orderHistoryList?.size ?: 0
    }

    fun setHistory (hists: ArrayList<OrderHistory>) {
        // not the best way to do this
        orderHistoryList = hists
        // invalidates all, pretty heavy handed
        // there are better ways
        notifyDataSetChanged()
    }

    //the class is hodling the list view
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindItems(orderHistory: OrderHistory) {
            val textViewDate = itemView.findViewById(R.id.order_date) as TextView
            val textViewDescription  = itemView.findViewById(R.id.order_description_item) as TextView
            textViewDate.text = orderHistory.orderDate.toString()
            textViewDescription.text = orderHistory.orderDescription
        }
    }
}