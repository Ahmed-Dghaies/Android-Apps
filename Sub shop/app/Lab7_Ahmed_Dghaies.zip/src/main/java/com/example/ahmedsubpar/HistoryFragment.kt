package com.example.ahmedsubpar

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ahmedsubpar.databinding.FragmentHistoryBinding
import kotlin.collections.ArrayList
import androidx.lifecycle.LiveData


class HistoryFragment : Fragment() {

    lateinit var binding: FragmentHistoryBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate(
            inflater, R.layout.fragment_history, container, false)

        //getting recyclerview from xml
        val recyclerView = binding.histRecyclerView

        //adding a layoutmanager
        recyclerView.layoutManager = LinearLayoutManager(context)

        binding.histRecyclerView.setHasFixedSize(true)
        //crating an arraylist to store users using the data class user

        //adding some dummy data to the list
        //orders.add(OrderHistory(null,"1", Date()))
        //orders.add(OrderHistory(null,"2", Date()))
        //orders.add(OrderHistory(null,"3", Date()))
        //orders.add(OrderHistory(null,"4", Date()))

        var viewModel = ViewModelProviders.of(this).get(HistViewModel::class.java)
        // listen to the viewModel’s data and
        // attach it to the adapter
        viewModel.getHistory()
            .observe(this,androidx.lifecycle.Observer {
                    // store a references to the adapter
                    val adapter = HistAdapter()
                    fun onChanged(t: ArrayList<OrderHistory>?) {
                        if (t != null) {
                            adapter.setHistory(t)
                        }
                    }
                })

        //creating our adapter
        val adapter = HistAdapter()

        //now adding the adapter to recyclerview
        recyclerView.adapter = adapter

            return binding.root
    }
}
