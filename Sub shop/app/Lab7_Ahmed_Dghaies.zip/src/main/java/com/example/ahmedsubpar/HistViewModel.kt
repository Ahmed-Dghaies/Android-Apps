package com.example.ahmedsubpar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData

class HistViewModel(app: Application): AndroidViewModel(app) {

    private val repository: HistRepository = HistRepository(app)
    private val history: LiveData<List<OrderHistory>> = repository.getHistory()

    fun getHistory(): LiveData<List<OrderHistory>> {
        return history
    }

    fun insertHistory(hist: OrderHistory)
    {
        repository.insertHistory(hist)
    }
}