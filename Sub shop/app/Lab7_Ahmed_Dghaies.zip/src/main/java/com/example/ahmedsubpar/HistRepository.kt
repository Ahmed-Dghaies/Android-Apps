package com.example.ahmedsubpar

import android.app.Application
import android.os.AsyncTask
import androidx.lifecycle.LiveData

class HistRepository(app: Application) {
    private var orderHistoryDao: OrderHistoryDao
    var tData: LiveData<List<OrderHistory>>
    init {
        val database: HistoryDatabase = HistoryDatabase.getInstance(app)
        orderHistoryDao = database.orderHistoryDao()
        tData = orderHistoryDao.getAll()
    }

    fun getHistory(): LiveData<List<OrderHistory>> {
        return tData
    }

    // In repository class
    fun insertHistory(orderHist: OrderHistory) {
        AsyncInsert(orderHistoryDao).execute(orderHist)
    }

    class AsyncInsert(val orderHistoryDao: OrderHistoryDao) : AsyncTask<OrderHistory, Void, Unit>() {
        override fun doInBackground(
            vararg orderHist: OrderHistory?) {
            // * here unpacks the varargs so it can be
            // use with insertAll
            orderHistoryDao.insertAll(*orderHist)
        }
    }
}