package com.example.ahmedsubpar

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

@Entity
data class OrderHistory(
    @PrimaryKey val orderId: Long?,
    @ColumnInfo(name = "order_description")
    val orderDescription: String,
    @ColumnInfo(name = "date")
    val orderDate: Date
)